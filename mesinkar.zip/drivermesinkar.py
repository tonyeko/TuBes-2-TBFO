from mesinkar import *

START('input.txt')
ADV()
ADV()
ADV()
ADV()
